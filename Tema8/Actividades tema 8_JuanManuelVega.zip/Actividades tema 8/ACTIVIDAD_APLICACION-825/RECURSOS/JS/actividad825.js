import _ from "https://cdn.jsdelivr.net/npm/lodash-es@4.17.21/lodash.js";

const numeros = [10, 20, 30];
console.log("Array original:", numeros);
console.log("Suma con Lodash:", _.sum(numeros));
